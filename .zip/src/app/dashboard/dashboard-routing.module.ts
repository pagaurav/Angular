import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { WelcomeComponent } from '../modules/welcome/welcome.component';
import { NgxDatatableComponent } from '../modules/ngx-datatable/ngx-datatable.component';
import { PipeComponent } from '../modules/pipe/pipe.component';
import { OperationComponent } from '../modules/operation/operation.component';
import { PagenotfoundfordashboardComponent } from '../modules/pagenotfoundfordashboard/pagenotfoundfordashboard.component';


const routes: Routes = [
  {path:'',component:DashboardComponent,
  
  children:[
    {path:'home', component:WelcomeComponent},
    {path:'', component:WelcomeComponent},
    {path:'viewquote',component:NgxDatatableComponent},
    {path:'pipe',component:PipeComponent},
    {path:'operation', component:OperationComponent},
    {path:'**',component:PagenotfoundfordashboardComponent}
  ]
},
{path:'**',component:PagenotfoundfordashboardComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
