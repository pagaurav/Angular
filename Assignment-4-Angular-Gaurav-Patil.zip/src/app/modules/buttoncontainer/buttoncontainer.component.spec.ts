import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtoncontainerComponent } from './buttoncontainer.component';

describe('ButtoncontainerComponent', () => {
  let component: ButtoncontainerComponent;
  let fixture: ComponentFixture<ButtoncontainerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ButtoncontainerComponent]
    });
    fixture = TestBed.createComponent(ButtoncontainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
