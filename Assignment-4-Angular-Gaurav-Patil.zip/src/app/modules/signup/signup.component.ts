import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  /**
   * signupForm created to stored username && password value
   */
  public signupForm = new FormGroup({
    userName : new FormControl("",[Validators.required]),
    password : new FormControl("",[Validators.required]),
    confirmPassword : new FormControl("",[Validators.required]),
  })

  constructor(private services:DataService, private toastr: ToastrService, private router : Router){}

  /**
   * 
   * @param controlName 
   * @returns 
   */
  public checkIfControlvalid (controlName:string): any {
    return this.signupForm.get(controlName)?.invalid &&
    this.signupForm.get(controlName)?.errors&&
    (this.signupForm.get(controlName)?.dirty || this.signupForm.get(controlName)?.touched )
  }

  /**
   * 
   * @param controlName 
   * @param error 
   * @returns 
   */
  public checkControlHasError (controlName:string , error:string): any {
    return this.signupForm.get(controlName)?.hasError(error)
  }  

  public submitForm () {

  }
}
