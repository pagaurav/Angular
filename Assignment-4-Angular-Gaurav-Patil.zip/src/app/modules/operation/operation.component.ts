import { Component } from '@angular/core';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss']
})
export class OperationComponent {
  public firstnumber: string = ""
  public secondnumber: string = ""
  public results : number = 0;
  public operationName : string = ""
  public showresult : boolean = false;

  displayOperation(result: number): void{
    this.results = result;
  }

  displayOperationName(operationName:string):void {
    this.operationName = operationName;
  }

  showResult(result:boolean) :void{
    this.showresult = result;
  }
}
