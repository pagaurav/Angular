import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  @Output() sideNavToggled = new EventEmitter<boolean>();
  menustatus: boolean = false;

  constructor(private route:Router){}

  /**
   * sideBartoggle in 
   */
  sideBartoggle() {
    console.log(this.menustatus);
    this.menustatus = !this.menustatus;
    this.sideNavToggled.emit(this.menustatus);
  }

  /**
   * logOut button go back to home screen
   * clear session storage
   */
  logOut () {
    localStorage.removeItem('userName');
    this.route.navigate(['./signin'])
  }
}
