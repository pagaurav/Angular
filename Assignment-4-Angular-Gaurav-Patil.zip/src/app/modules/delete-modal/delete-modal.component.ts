import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter,Input,Output } from '@angular/core';
import { DataService } from '../../shared/services/data.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.scss']
})
export class DeleteModalComponent {
  @Input() quote : any ;
  @Output() close = new EventEmitter();

  constructor(public http: HttpClient, 
    public services: DataService ,
    private toastr: ToastrService
    ){}

    
    public Delete() : void {
      this.services.deleteDataservice(this.quote).subscribe(() => {
        this.toastr.success("Quote adding successfully","success")
        this.onClose();
      },(error : any) => {
        this.toastr.error("eroor Updating quote","error")
      })
    }

    public onClose() : void {
      this.close.emit();
    }
  
}
