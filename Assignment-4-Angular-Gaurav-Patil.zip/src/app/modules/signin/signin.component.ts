import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent {

  /**
   * signform created to stored username && password value
   */
  public signForm = new FormGroup({
    userName : new FormControl("",[Validators.required]),
    password : new FormControl("",[Validators.required]),
  })
 

  constructor(private services:DataService, private toastr: ToastrService, private router : Router){}

  /**
   * 
   * @param controlName 
   * @returns 
   */
  public checkIfControlvalid (controlName:string): any {
    return this.signForm.get(controlName)?.invalid &&
    this.signForm.get(controlName)?.errors&&
    (this.signForm.get(controlName)?.dirty || this.signForm.get(controlName)?.touched )
  }

  /**
   * 
   * @param controlName 
   * @param error 
   * @returns 
   */
  public checkControlHasError (controlName:string , error:string): any {
    return this.signForm.get(controlName)?.hasError(error)
  }

  /**
   * 
   */
  submitForm( ){
    let userName: any = this.signForm.get('userName')?.value;
    let password: any = this.signForm.get('password')?.value;
    
    this.services.getUserDataservice().subscribe((response:any[]) => {
      let users = response.findIndex((user):any => {
        if (user.userName.toLowerCase() != userName.toLowerCase() ) {
          this.toastr.error('Invalid Username ', 'Error')
        }
        else if(user.password != password) {
          this.toastr.error('Invalid Password', 'Error')
        }
        else {
          return true;
        }
      })
      console.log(users);
                              
      if (users != -1) {
        localStorage.setItem("userName", userName?.toLowerCase());
        this.toastr.success('User logged in successsfully', 'Success')        
        this.router.navigate(['/dashboard'])
      }
    }, () => {
      this.toastr.error('Error jg', 'Error')
    })
  }
}
