import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() sidenavStatus : boolean = false;
  
  /**
   * sidebarContent to add sidebar dynamic from json
   */
  sidebarContent = [
    {
      number : '1',
      name : 'home',
      routerLink : '/dashboard',
      icon : 'fa-solid fa-house'
    },
    {
      number : '2',
      name : 'operation',
      routerLink : '/dashboard/operation',
      icon : 'fa-solid fa-chart-line'
    },
    {
      number : '3',
      name : 'Add Note',
      routerLink : '/dashboard/addnote',
      icon : 'fa-solid fa-box'
    },
    {
      number : '4',
      name : 'View Note',
      routerLink : '/dashboard/viewquote',
      icon : 'fa-solid fa-cart-shopping'
    },
    {
      number : '5',
      name : 'pipe',
      routerLink : '/dashboard//pipe',
      icon : 'fa-solid fa-eye'
    },
    {
      number : '6',
      name : 'setting',
      routerLink : '/dashboard/setting',
      icon : 'fa-solid fa-gear'
    },
    {
      number : '7',
      name : 'about',
      routerLink : '/dashboard/about',
      icon : 'fa-solid fa-circle-info'
    },
    {
      number : '8',
      name : 'contact',
      routerLink : '/dashboard/contact',
      icon : 'fa-solid fa-phone'
    }  
  ]

}
