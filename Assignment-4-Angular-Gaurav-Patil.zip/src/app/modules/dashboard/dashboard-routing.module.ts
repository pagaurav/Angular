import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { WelcomeComponent } from '../welcome/welcome.component';
import { NgxDatatableComponent } from '../ngx-datatable/ngx-datatable.component';
import { PipeComponent } from '../pipe/pipe.component';
import { OperationComponent } from '../operation/operation.component';
import { PagenotfoundfordashboardComponent } from '../pagenotfoundfordashboard/pagenotfoundfordashboard.component';
import { AuthGuard } from 'src/app/shared/helper/auth.guard';


const routes: Routes = [
  {path:'',component:DashboardComponent,
  
  children:[
    {path:'home', component:WelcomeComponent,canActivate:[AuthGuard]},
    {path:'', component:WelcomeComponent,canActivate:[AuthGuard]},
    {path:'viewquote',component:NgxDatatableComponent,canActivate:[AuthGuard]},
    {path:'pipe',component:PipeComponent,canActivate:[AuthGuard]},
    {path:'operation', component:OperationComponent,canActivate:[AuthGuard]},
    {path:'**',component:PagenotfoundfordashboardComponent,canActivate:[AuthGuard]}
  ],canActivate:[AuthGuard]
},
{path:'**',component:PagenotfoundfordashboardComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
