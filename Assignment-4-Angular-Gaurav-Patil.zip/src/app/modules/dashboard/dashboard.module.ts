import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ngx-toastr';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,FormsModule,
    DashboardRoutingModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    ModalModule.forRoot(),
    ToastrModule.forRoot(),
  ]
})
export class DashboardModule { }