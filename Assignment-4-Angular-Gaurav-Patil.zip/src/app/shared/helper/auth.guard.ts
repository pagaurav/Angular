import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class AuthGuard {
  constructor( private route:Router ) { }

  /**
   * Checks if the user can visit the specific route.
   * @returns Returns true if the user is logged in and can visit the route, otherwise returns false
   */
  canActivate() {
    let isUserLoggedIn = localStorage.getItem('userName') !== null;
    if(isUserLoggedIn) {
      return true;
    }
    else {
      this.route.navigate(['/login']);
      return false;
    }
  }
}