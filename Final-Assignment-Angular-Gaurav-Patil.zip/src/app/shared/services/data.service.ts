import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DataService {
  constructor(public http:HttpClient) { }
  getDataservice () : any {
    return this.http.get('http://localhost:3000/quote')
  }

  getUserDataservice () : any {
    return this.http.get('http://localhost:3000/user')
  }
  
  addUserDataservice (user:any) : any {
    return this.http.post('http://localhost:3000/user',user);
  }

  addDataservice (quote:any) : any {
    return this.http.post('http://localhost:3000/quote',quote);
  }

  updateDataservice (quote:any) : any {
    return this.http.put(`http://localhost:3000/quote/${quote.id}`,quote);
  }
  
  deleteDataservice (quote:any) : any {
    return this.http.delete(`http://localhost:3000/quote/${quote.id}`,quote);
  }
}
