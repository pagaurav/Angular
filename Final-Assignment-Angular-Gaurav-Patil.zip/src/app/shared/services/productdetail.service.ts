import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductdetailService {

  constructor(public http:HttpClient) { }

  addProductDataservice (productDetail:any) : any {
    return this.http.post('http://localhost:3000/productDetail',productDetail);
  }

  getProductDetailDataservice () : any {
    return this.http.get('http://localhost:3000/productDetail')
  }
  deleteDataservice (productDetail:any) : any {
    return this.http.delete(`http://localhost:3000/productDetail/${productDetail.id}`,productDetail);
  }
}
