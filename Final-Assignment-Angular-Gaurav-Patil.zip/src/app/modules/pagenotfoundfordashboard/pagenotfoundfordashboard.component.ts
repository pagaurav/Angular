import { Component } from '@angular/core';

@Component({
  selector: 'app-pagenotfoundfordashboard',
  templateUrl: './pagenotfoundfordashboard.component.html',
  styleUrls: ['./pagenotfoundfordashboard.component.scss']
})
export class PagenotfoundfordashboardComponent {

}
