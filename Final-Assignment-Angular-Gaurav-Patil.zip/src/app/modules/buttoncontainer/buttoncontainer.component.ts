import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-buttoncontainer',
  templateUrl: './buttoncontainer.component.html',
  styleUrls: ['./buttoncontainer.component.scss']
})
export class ButtoncontainerComponent {
  public result: number = 0
  public operationname: string = "";
  @Input() firstnumber = "" ;
  @Input() secondnumber = "";
  public showresults: boolean = false;
  @Output() results = new EventEmitter<number>();
  @Output() operationName = new EventEmitter<string>();
  @Output() showresult = new EventEmitter<boolean>();

  constructor(private toastr: ToastrService ) {}

  /**
   * onclick of Addition button addition of two number
   */
  addition() {
    this.toastr.success('Addition Sucessfull', 'Sucess');
    this.result = parseInt(this.firstnumber) + parseInt(this.secondnumber);
    this.operationname = "Addition is : ";
    this.showresults = true;
    this.operationName.emit(this.operationname);
    this.results.emit(this.result);
    this.showresult.emit(this.showresults);
  }

  /**
   * onclick of Substraction button Substraction of two number
   */
  substraction() {
    this.toastr.success('Substraction Sucessfull', 'Sucess');
    this.result = parseInt(this.firstnumber) - parseInt(this.secondnumber);
    this.operationname = "Substraction is : ";
    this.operationName.emit(this.operationname);
    this.results.emit(this.result);
  }

  /**
   * onclick of Division button Division of two number
   */
  division() {
    this.toastr.success('Division Sucessfull', 'Sucess');
    this.result = parseInt(this.firstnumber) / parseInt(this.secondnumber);
    this.operationname = "Division  is : ";
    this.operationName.emit(this.operationname);
    this.results.emit(this.result);
  }

  /**
   * onclick of multiplication button multiplications of two number
   */
  multiplication() {
    this.toastr.success('Multiplication Sucessfull', 'Sucess');
    this.result = parseInt(this.firstnumber) * parseInt(this.secondnumber);
    this.operationname = "Multiplication is : ";
    this.operationName.emit(this.operationname);
    this.results.emit(this.result);
  }
}
