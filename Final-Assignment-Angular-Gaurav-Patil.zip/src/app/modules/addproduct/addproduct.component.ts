import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Route, Router, Routes } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductdetailService } from 'src/app/shared/services/productdetail.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.scss']
})
export class AddproductComponent {
  public productDetail: any = [];

  constructor(public http: HttpClient,
    public services: ProductdetailService,
    private toastr: ToastrService,
    private router:Router
  ) { }

  public productDetailForm = new FormGroup({
    customerName: new FormControl("", [Validators.required]),
    contact: new FormControl("", [Validators.required]),
    date: new FormControl("", [Validators.required]),
    productType: new FormControl("", [Validators.required]),
    companyName: new FormControl("", [Validators.required]),
  })

   /**
   * The function checks if a form control is invalid and has errors, and if it has been modified or
   * touched.
   * @param {string} controlName - The controlName parameter is a string that represents the name of a
   * control in a form.
   * @returns a boolean value.
   */
   public checkIfControlvalid(controlName: string): any {
    return this.productDetailForm.get(controlName)?.invalid &&
      this.productDetailForm.get(controlName)?.errors &&
      (this.productDetailForm.get(controlName)?.dirty || this.productDetailForm.get(controlName)?.touched)
  }

  /**
   * The function checks if a specific control in a quote form has a specific error.
   * @param {string} controlName - The name of the form control you want to check for errors. This
   * should be a string value.
   * @returns the result of the `hasError` method called on the `productDetailForm` control with the specified
   * `controlName` and `error` parameters.
   */
  public checkControlHasError(controlName: string, error: string): any {
    return this.productDetailForm.get(controlName)?.hasError(error)
  }

  public onSubmitProductDetail() {
    let payload = this.assignvalueModel();
    this.addProductDetail(payload);
  }

  public addProductDetail(payload: any): void {
    this.services.addProductDataservice(payload).subscribe((response: any) => {
      this.toastr.success("Quote adding successfully", "success")
      this.router.navigate(['dashboard/product-management'])
    }, (error: any) => {
      this.toastr.error("eroor adding quote", "error")
    })
  }

  public backToProductList () {
    this.router.navigate(['dashboard/product-management'])
  }
  private assignvalueModel(): any {
    let productDetail = {
      "customerName": this.productDetailForm.get('customerName')?.value,
      "contact": this.productDetailForm.get('contact')?.value,
      "date": this.productDetailForm.get('date')?.value,
      "productType": this.productDetailForm.get('productType')?.value,
      "companyName": this.productDetailForm.get('companyName')?.value,
    };
    return productDetail;
  }
}
